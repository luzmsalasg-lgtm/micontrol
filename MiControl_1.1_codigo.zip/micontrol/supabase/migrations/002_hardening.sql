-- MiControl 1.1: aplicar después de 001_initial.sql.
-- Ejecutar como administrador del proyecto en Supabase SQL Editor.
begin;

-- Los clientes se archivan, no se borran. Conservar relaciones e historial.
create or replace function public.protect_client_history()
returns trigger language plpgsql set search_path = '' as $$
begin
  raise exception 'Archiva el cliente en lugar de eliminarlo';
end $$;
drop trigger if exists clients_no_delete on public.clients;
create trigger clients_no_delete before delete on public.clients
for each row execute function public.protect_client_history();

-- Evitar cambios de propietario en registros ya existentes.
create or replace function public.protect_owner()
returns trigger language plpgsql set search_path = '' as $$
begin
  if new.owner_id is distinct from old.owner_id then
    raise exception 'No se permite cambiar el propietario';
  end if;
  return new;
end $$;
do $$
declare t text;
begin
  foreach t in array array['profiles','clients','contracts','payments','tasks','campaigns','documents'] loop
    execute format('drop trigger if exists protect_owner on public.%I',t);
    execute format('create trigger protect_owner before update on public.%I for each row execute function public.protect_owner()',t);
  end loop;
end $$;

-- La ruta del documento debe estar bajo el UUID del propietario.
alter table public.documents
  add constraint documents_owner_path_check
  check (split_part(storage_path, '/', 1) = owner_id::text);
alter table public.documents
  add constraint documents_mime_check
  check (mime_type in ('application/pdf','image/png','image/jpeg','text/plain'));
alter table public.documents
  add constraint documents_name_check
  check (length(btrim(name)) between 1 and 255);

-- Restricciones de fechas.
alter table public.contracts
  add constraint contracts_dates_check
  check (due_date is null or start_date is null or due_date >= start_date);
alter table public.campaigns
  add constraint campaigns_dates_check
  check (end_date is null or start_date is null or end_date >= start_date);

-- Impedir que se cambie el propietario o contrato de un abono,
-- y preservar abonos como anulaciones en vez de eliminarlos.
create or replace function public.protect_payment_delete()
returns trigger language plpgsql set search_path = '' as $$
begin
  raise exception 'Anula el abono (status=void) en vez de eliminarlo';
end $$;
drop trigger if exists payments_no_delete on public.payments;
create trigger payments_no_delete before delete on public.payments
for each row execute function public.protect_payment_delete();

-- Bloquear la fila del contrato al actualizar importe: evita carreras
-- con nuevas inserciones de pagos, que también bloquean el contrato.
create or replace function public.prevent_contract_underpayment()
returns trigger language plpgsql set search_path = '' as $$
declare total_paid numeric(16,2);
begin
  select coalesce(sum(amount),0) into total_paid
  from public.payments
  where contract_id = old.id and status = 'valid';
  if new.amount < total_paid then
    raise exception 'El importe no puede ser inferior a los abonos existentes';
  end if;
  return new;
end $$;

-- Impedir asignar un documento a un cliente de otro propietario ya está
-- cubierto por FK compuesta en 001_initial.sql.
commit;

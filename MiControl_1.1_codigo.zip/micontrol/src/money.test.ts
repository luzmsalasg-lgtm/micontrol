import {it,expect} from 'vitest';
import {balance} from './money';
it('descuenta solo pagos válidos',()=>expect(balance(100,[{amount:20,status:'valid'},{amount:30,status:'void'}])).toBe(80));
it('soporta centavos',()=>expect(balance(100.1,[{amount:0.2,status:'valid'}])).toBe(99.9));
it('admite múltiples abonos',()=>expect(balance(100,[{amount:25,status:'valid'},{amount:40,status:'valid'}])).toBe(35));

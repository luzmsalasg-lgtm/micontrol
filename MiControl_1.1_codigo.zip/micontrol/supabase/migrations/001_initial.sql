
create extension if not exists pgcrypto;
create table public.allowed_users (user_id uuid primary key references auth.users(id) on delete cascade);
create function public.is_allowed() returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.allowed_users where user_id=(select auth.uid()))$$;
revoke all on function public.is_allowed() from public;
grant execute on function public.is_allowed() to authenticated;
create table public.profiles(owner_id uuid primary key references auth.users(id), full_name text not null default '', default_currency text not null default 'PEN' check(default_currency ~ '^[A-Z]{3}$'), created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.clients(id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id), name text not null check(length(trim(name))>0), email text, phone text, notes text, archived boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(id,owner_id));
create table public.contracts(id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id), client_id uuid not null, service text not null check(length(trim(service))>0), amount numeric(16,2) not null check(amount>=0), currency text not null check(currency ~ '^[A-Z]{3}$'), start_date date, due_date date, status text not null default 'active' check(status in ('draft','active','completed','cancelled')), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(id,owner_id), foreign key(client_id,owner_id) references public.clients(id,owner_id));
create table public.payments(id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id), contract_id uuid not null, amount numeric(16,2) not null check(amount>0), paid_on date not null default current_date, status text not null default 'valid' check(status in ('valid','void')), notes text, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), foreign key(contract_id,owner_id) references public.contracts(id,owner_id));
create table public.tasks(id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id), client_id uuid, title text not null check(length(trim(title))>0), due_date date, priority text not null default 'normal' check(priority in ('low','normal','high')), status text not null default 'pending' check(status in ('pending','doing','done')), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), foreign key(client_id,owner_id) references public.clients(id,owner_id));
create table public.campaigns(id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id), client_id uuid not null, platform text not null, objective text not null default '', budget numeric(16,2) not null default 0 check(budget>=0), spend numeric(16,2) not null default 0 check(spend>=0), currency text not null default 'PEN' check(currency ~ '^[A-Z]{3}$'), start_date date, end_date date, results text, notes text, status text not null default 'active' check(status in ('planned','active','paused','finished')), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), foreign key(client_id,owner_id) references public.clients(id,owner_id));
create table public.documents(id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id), client_id uuid, name text not null, storage_path text not null unique, mime_type text not null, size_bytes bigint not null check(size_bytes between 1 and 10485760), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), foreign key(client_id,owner_id) references public.clients(id,owner_id));
create function public.touch_updated() returns trigger language plpgsql set search_path='' as $$begin new.updated_at=now(); return new; end$$;
do $$
declare t text;
begin
foreach t in array array['profiles','clients','contracts','payments','tasks','campaigns','documents'] loop
 execute format('create trigger touch before update on public.%I for each row execute function public.touch_updated()',t);
 execute format('alter table public.%I enable row level security',t);
 if t <> 'profiles' then
  execute format('create policy owner_select on public.%I for select to authenticated using (owner_id=(select auth.uid()) and (select public.is_allowed()))',t);
  execute format('create policy owner_insert on public.%I for insert to authenticated with check (owner_id=(select auth.uid()) and (select public.is_allowed()))',t);
  execute format('create policy owner_update on public.%I for update to authenticated using (owner_id=(select auth.uid()) and (select public.is_allowed())) with check (owner_id=(select auth.uid()) and (select public.is_allowed()))',t);
  execute format('create policy owner_delete on public.%I for delete to authenticated using (owner_id=(select auth.uid()) and (select public.is_allowed()))',t);
 end if;
end loop;
end $$;
create policy profile_select on public.profiles for select to authenticated using(owner_id=(select auth.uid()) and (select public.is_allowed()));
create policy profile_insert on public.profiles for insert to authenticated with check(owner_id=(select auth.uid()) and (select public.is_allowed()));
create policy profile_update on public.profiles for update to authenticated using(owner_id=(select auth.uid()) and (select public.is_allowed())) with check(owner_id=(select auth.uid()) and (select public.is_allowed()));
alter table public.allowed_users enable row level security;
create index on public.clients(owner_id,archived);
create index on public.contracts(owner_id,client_id);
create index on public.payments(owner_id,contract_id);
create index on public.tasks(owner_id,due_date);
create index on public.campaigns(owner_id,status);
create index on public.documents(owner_id,client_id);
create function public.prevent_overpayment() returns trigger language plpgsql security invoker set search_path='' as $$
declare total numeric(16,2); paid numeric(16,2);
begin
select amount into total from public.contracts where id=new.contract_id and owner_id=new.owner_id for update;
if total is null then raise exception 'Contrato no disponible'; end if;
if new.status='valid' then
select coalesce(sum(amount),0) into paid from public.payments where contract_id=new.contract_id and status='valid' and id<>new.id;
if paid+new.amount>total then raise exception 'El pago supera el saldo del contrato'; end if;
end if;
return new;
end$$;
create trigger validate_payment before insert or update on public.payments for each row execute function public.prevent_overpayment();
create function public.prevent_contract_underpayment() returns trigger language plpgsql set search_path='' as $$
begin
if new.amount < (select coalesce(sum(amount),0) from public.payments where contract_id=old.id and status='valid') then raise exception 'El importe no puede ser inferior a los abonos existentes'; end if;
return new;
end$$;
create trigger validate_contract before update of amount on public.contracts for each row execute function public.prevent_contract_underpayment();
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('private-documents','private-documents',false,10485760,array['application/pdf','image/png','image/jpeg','text/plain']) on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
create policy private_read on storage.objects for select to authenticated using(bucket_id='private-documents' and (storage.foldername(name))[1]=(select auth.uid())::text and (select public.is_allowed()));
create policy private_insert on storage.objects for insert to authenticated with check(bucket_id='private-documents' and (storage.foldername(name))[1]=(select auth.uid())::text and (select public.is_allowed()));
create policy private_delete on storage.objects for delete to authenticated using(bucket_id='private-documents' and (storage.foldername(name))[1]=(select auth.uid())::text and (select public.is_allowed()));

create function public.prevent_payment_reassignment() returns trigger language plpgsql set search_path='' as $$
begin
if new.contract_id<>old.contract_id or new.owner_id<>old.owner_id then raise exception 'No se permite cambiar el contrato de un abono'; end if;
return new;
end$$;
create trigger payment_immutable_parent before update on public.payments for each row execute function public.prevent_payment_reassignment();

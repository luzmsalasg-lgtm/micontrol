export function balance(amount:number,payments:{amount:number,status:string}[]){return Math.round((amount-payments.filter(p=>p.status==='valid').reduce((s,p)=>s+p.amount,0))*100)/100}

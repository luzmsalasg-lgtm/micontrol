# MiControl 1.1 — Nivel PRO

Aplicación React + TypeScript + Tailwind + Supabase. Requiere configuración externa; no hay datos simulados ni credenciales incluidas.

## Preparación
1. Crear proyecto privado en Supabase.
2. En Authentication > Providers > Email, desactivar **Allow new users to sign up**; configurar correo SMTP para recuperación en producción y Site URL + Redirect URLs al dominio HTTPS de Netlify.
3. Ejecutar `supabase/migrations/001_initial.sql` y después `supabase/migrations/002_hardening.sql` en SQL Editor (una vez en proyecto nuevo). El script crea tablas, RLS, validaciones y bucket privado.
4. En Authentication > Users, crear manualmente la única cuenta, con contraseña fuerte, desde la administración. Copiar su UUID.
5. En SQL Editor, como administrador, ejecutar `insert into public.allowed_users(user_id) values ('UUID_DE_LA_CUENTA');`. **No ejecutar desde el navegador.** No autorizar más cuentas.
6. Copiar `.env.example` a `.env.local` y sustituir URL y clave **publicable/anon** de Supabase. Jamás usar `service_role`.
7. Ejecutar `npm install`, `npm run dev`. Abrir la URL indicada por Vite.
8. Ejecutar `npm run build` y `npm run test`.

## Publicación Netlify
Subir a Git, conectar repositorio a Netlify; build `npm run build`, publish `dist`. Configurar `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY` en variables del sitio y volver a desplegar. `netlify.toml` proporciona fallback SPA. Confirmar HTTPS y actualizar URLs de Auth en Supabase. Netlify no aloja la base PostgreSQL.

## Datos y restauración
Configuración > Exportar descarga JSON de tablas. **No es una copia integral**: los archivos de Storage no se incluyen. Para respaldos fiables usar backups gestionados de Supabase o `pg_dump` con conexión administrativa segura, y copiar objetos del bucket privado por una herramienta administrativa. Restaurar en proyecto aislado con `pg_restore` (según formato) y restaurar los objetos; comprobar referencias, UUID, RLS y acceso antes de cambiar producción. Nunca subir un backup con datos privados a un repositorio.

## Pruebas necesarias
- Login válido, contraseña incorrecta, recuperación por correo y expiración de sesión.
- Crear/editar/archivar cliente; varios contratos por cliente y varios abonos por contrato.
- Pago negativo, pago mayor al saldo y dos pagos simultáneos (deben rechazarse).
- Verificar que usuario anónimo y otra cuenta no autorizada no pueden leer, escribir ni descargar archivos (RLS + Storage).
- Subida y descarga PDF/PNG/JPG/TXT, rechazo de archivo mayor a 10 MB y de MIME no permitido.
- Responsive 360px, teclado, errores de red, producción HTTPS.
- Restaurar un backup en un proyecto de pruebas.

## Límites conocidos
No se incluye función de restauración desde la interfaz, importación masiva, auditoría histórica de cambios ni pruebas end-to-end automatizadas. La exportación JSON es una copia lógica de registros, no un backup transaccional. Los clientes se archivan y los pagos se anulan (`void`) para conservar historial. Otras entidades aún admiten eliminación y requieren política de retención según el uso. No registrar contraseñas de terceros. La seguridad de producción requiere auditoría y pruebas reales en Supabase.


## Cambios en 1.1
- Flujo para establecer nueva contraseña tras enlace de recuperación de Supabase.
- Archivar clientes desde la interfaz sin borrar contratos asociados.
- Anular cobros en vez de eliminarlos; prohibición de reasignarlos.
- Segunda migración: protección de propietario, validación de rutas y MIME de documentos, restricciones de fechas, bloqueos de borrado de clientes y pagos.
- Recomendación: antes de datos reales, revisar integridad referencial, sesiones, RLS y almacenamiento en Supabase.

## Estado de pruebas de esta entrega
- Se comprobó la presencia y estructura de los archivos y la integridad del ZIP.
- `npm install --offline` no pudo completarse porque faltan dependencias en caché.
- **No se ejecutaron** compilación TypeScript, tests Vitest, tests E2E ni pruebas contra Supabase real.
- Las políticas SQL y el flujo de recuperación requieren pruebas en un proyecto aislado.
- No se ha publicado ni configurado ninguna cuenta, base de datos o proveedor de correo.

## Pruebas SQL de autorización a ejecutar
1. Sin JWT: consultas y mutaciones de tablas privadas deben fallar o devolver cero filas.
2. Usuario no autorizado: `is_allowed()` falso y sin acceso a tablas ni bucket.
3. Usuario autorizado: operaciones solo sobre filas de su UUID.
4. Intentar cambiar `owner_id`, borrar cliente o pago, crear documento con ruta ajena, crear sobrepago: deben fallar.
5. Dos sesiones concurrentes intentando abonar el saldo restante: solo una debe poder completar la operación.
6. Probar recuperación por correo, cambio de contraseña, sesión caducada, MIME y límite de tamaño de Storage.
